package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarDealershipProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarDealershipProjectApplication.class, args);
	}

}
